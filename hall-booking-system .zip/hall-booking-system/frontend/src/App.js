import BookingList from "./BookingList";
function App(){ return <BookingList/> }
export default App;
